package com.cts.dto;

import lombok.Data;

@Data
public class ProductDTO {
	//private Integer bookId;
    private int quantity;

}
