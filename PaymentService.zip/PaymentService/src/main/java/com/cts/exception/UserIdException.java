package com.cts.exception;

public class UserIdException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public UserIdException(String message) {
		super(message);
	}

}
